(function () {
  var language = document.documentElement.lang === "en" ? "en" : "es";
  var whatsappUrl = "https://wa.me/message/RJTK6JZQVBQKC1";
  var googleFormUrl = "https://docs.google.com/forms/d/e/1FAIpQLSdDKwjCPPYwfmxu4_XR_SCBBoyMVc9oL-Zbjer486lz39R3Ig/viewform?embedded=true";
  var strings = {
    es: {
      open: "Abrir opciones de contacto",
      title: "Contacta a un representante",
      close: "Cerrar opciones de contacto",
      whatsapp: "Contactar por WhatsApp",
      register: "Llenar formulario para que me contacten",
      back: "Volver a opciones",
      formTitle: "Formulario de contacto",
    },
    en: {
      open: "Open contact options",
      title: "Contact a representative",
      close: "Close contact options",
      whatsapp: "Contact on WhatsApp",
      register: "Fill out the contact form",
      back: "Back to contact options",
      formTitle: "Contact form",
    },
  };

  function initialize() {
    var labels = strings[language];
    var shell = document.createElement("div");
    shell.className = "contact-shell";
    shell.innerHTML =
      '<button class="contact-launcher" type="button" aria-label="' + labels.open + '" aria-expanded="false">' +
        '<img src="img/logowhatsapp.png" alt="" aria-hidden="true">' +
      '</button>' +
      '<section class="contact-panel" role="dialog" aria-modal="false" aria-label="' + labels.title + '" hidden>' +
        '<header class="contact-header"><strong>' + labels.title + '</strong><button class="contact-close" type="button" aria-label="' + labels.close + '">×</button></header>' +
        '<div class="contact-options">' +
          '<a class="contact-option contact-option-whatsapp" href="' + whatsappUrl + '" target="_blank" rel="noopener noreferrer">' +
            '<img src="img/logowhatsapp.png" alt="" aria-hidden="true"><span>' + labels.whatsapp + '</span>' +
          '</a>' +
          '<button class="contact-option contact-option-register" type="button">' + labels.register + '</button>' +
        '</div>' +
        '<div class="contact-form-view" hidden>' +
          '<button class="contact-back" type="button">' + labels.back + '</button>' +
          '<iframe title="' + labels.formTitle + '" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>' +
        '</div>' +
      '</section>';

    document.body.appendChild(shell);

    var launcher = shell.querySelector(".contact-launcher");
    var panel = shell.querySelector(".contact-panel");
    var closeButton = shell.querySelector(".contact-close");
    var whatsappLink = shell.querySelector(".contact-option-whatsapp");
    var registerButton = shell.querySelector(".contact-option-register");
    var options = shell.querySelector(".contact-options");
    var formView = shell.querySelector(".contact-form-view");
    var formFrame = formView.querySelector("iframe");
    var backButton = shell.querySelector(".contact-back");

    function setOpen(isOpen) {
      panel.hidden = !isOpen;
      launcher.setAttribute("aria-expanded", String(isOpen));
      shell.classList.toggle("is-open", isOpen);
      if (isOpen) whatsappLink.focus({ preventScroll: true });
    }

    launcher.addEventListener("click", function () {
      setOpen(panel.hidden);
    });
    closeButton.addEventListener("click", function () {
      setOpen(false);
      launcher.focus();
    });
    registerButton.addEventListener("click", function () {
      options.hidden = true;
      formView.hidden = false;
      panel.classList.add("is-form-open");
      if (!formFrame.hasAttribute("src")) formFrame.src = googleFormUrl;
      backButton.focus({ preventScroll: true });
    });
    backButton.addEventListener("click", function () {
      formFrame.removeAttribute("src");
      formView.hidden = true;
      options.hidden = false;
      panel.classList.remove("is-form-open");
      registerButton.focus({ preventScroll: true });
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && !panel.hidden) {
        setOpen(false);
        launcher.focus();
      }
    });
  }

  var stylesheet = document.createElement("link");
  stylesheet.rel = "stylesheet";
  stylesheet.href = "css/contact-widget.css?v=20261003c";
  stylesheet.addEventListener("load", initialize, { once: true });
  stylesheet.addEventListener("error", initialize, { once: true });
  document.head.appendChild(stylesheet);
})();